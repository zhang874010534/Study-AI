import os

import dotenv
from langchain_core.prompts import ChatPromptTemplate
from datetime import datetime
from openai import OpenAI
from langchain_openai import ChatOpenAI
dotenv.load_dotenv()

prompt = ChatPromptTemplate.from_messages([
    ("system", "回答用户的问题,现在的时间是{now}"),
    ("human", "{query}"),
]).partial(now=datetime.now())

api_key = os.getenv("ARK_API_KEY")
llm = ChatOpenAI(
    model="ep-20260827220313-29tvz",
    base_url="https://ark.cn-beijing.volces.com/api/v3",
    api_key=api_key,
)

ai_message = llm.invoke(prompt.invoke({"query": "现在是几点,讲一个笑话给我"}))

print(ai_message.type)
print(ai_message.content)
print(ai_message.response_metadata)
